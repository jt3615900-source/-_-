# 🦸 MRTOM VPS

Script Bash modulaire pour Ubuntu 22.04/24.04 destiné à installer et gérer un serveur VPS multi-services.

## Important

Plusieurs services de la liste originale demandent le même port (notamment 80 et 443). Deux processus ne peuvent pas écouter directement le même `IP:port`. MRTOM utilise donc une architecture modulaire et des ports internes distincts lorsque le multiplexage n'est pas configuré.

Le module Xray est prévu pour regrouper plusieurs protocoles derrière un point d'entrée TLS/WS/gRPC. Les modules `ZIV VPN` et `UDP Custom` sont volontairement des modules d'intégration : leurs implémentations dépendent du logiciel/protocole exact que vous utilisez.

## Système conseillé

- Ubuntu 22.04 ou 24.04
- domaine A/AAAA pointant vers le VPS
- accès root
- ports 22, 80 et 443 accessibles

## Installation

```bash
git clone https://github.com/VOTRE-COMPTE/MRTOM.git
cd MRTOM
chmod +x install.sh
sudo ./install.sh
```

L'installateur demande :
1. domaine
2. serveur NS principal
3. serveur NS secondaire (optionnel)

Le domaine doit être configuré chez votre registrar/DNS avant d'activer les certificats TLS.

## Arborescence

- `install.sh` : installateur principal
- `lib/` : fonctions communes
- `modules/` : modules indépendants
- `config/` : configuration générée
- `banner/` : bannière de connexion
- `systemd/` : unités de services personnalisées

## Gestion

Après installation :

```bash
mrtom
```

Commandes principales :

```text
mrtom install all
mrtom install ssh
mrtom install dropbear
mrtom install nginx
mrtom install xray
mrtom install openvpn
mrtom install shadowsocks
mrtom install slowdns
mrtom install ziv
mrtom install udp
mrtom status
mrtom banner
mrtom ports
mrtom update
mrtom uninstall <module>
```

## Sécurité

Le script ne crée pas de comptes avec des mots de passe codés en dur. Créez les utilisateurs avec :

```bash
mrtom user add NOM_UTILISATEUR
```

Utilisez des mots de passe uniques et limitez les ports exposés par votre pare-feu.

## Licence

MIT
