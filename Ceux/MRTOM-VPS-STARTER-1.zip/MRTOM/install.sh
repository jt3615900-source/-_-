#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$ROOT_DIR/lib/common.sh"

require_root
detect_os
collect_domain
install_base
install_manager
install_banner

echo
echo "╔════════════════════════════════════════════╗"
echo "║              🦸 MRTOM VPS 🦸               ║"
echo "╚════════════════════════════════════════════╝"
echo
echo "Domaine : ${MRTOM_DOMAIN}"
echo "NS      : ${MRTOM_NS1:-non défini}"
echo
echo "Installation de base terminée."
echo "Lancez ensuite : mrtom install all"
