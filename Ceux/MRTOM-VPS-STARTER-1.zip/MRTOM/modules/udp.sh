#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
UDP Custom : module d'intégration.
N'ouvrez pas automatiquement 1-65535 : cela augmente fortement la surface d'attaque.
Déclarez uniquement les ports UDP réellement utilisés par votre application.
Exemple : OpenVPN UDP 2200.
EOF
