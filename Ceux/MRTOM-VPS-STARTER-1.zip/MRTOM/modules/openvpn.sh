#!/usr/bin/env bash
set -euo pipefail
apt-get install -y openvpn easy-rsa
mkdir -p /etc/openvpn/server
echo "[OK] OpenVPN installé."
echo "Ports recommandés dans cette architecture : TCP 1194 et UDP 2200."
echo "Générez ensuite vos certificats avec easy-rsa."
