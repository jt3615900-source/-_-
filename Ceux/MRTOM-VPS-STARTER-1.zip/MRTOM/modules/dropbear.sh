#!/usr/bin/env bash
set -euo pipefail
apt-get install -y dropbear
# Dropbear utilise 109 par défaut dans cette architecture pour éviter un conflit avec 80/443.
sed -i 's/^DROPBEAR_PORT=.*/DROPBEAR_PORT=109/' /etc/default/dropbear 2>/dev/null || true
grep -q '^DROPBEAR_PORT=' /etc/default/dropbear 2>/dev/null || echo 'DROPBEAR_PORT=109' >> /etc/default/dropbear
systemctl enable --now dropbear
echo "[OK] Dropbear : 109"
