#!/usr/bin/env bash
set -euo pipefail
apt-get install -y bind9 dnsutils
systemctl enable --now bind9
echo "[OK] DNS de base installé."
echo "Le véritable SlowDNS nécessite un client/serveur compatible (iodine ou logiciel équivalent)."
echo "Aucune redirection DNS clandestine n'est créée par ce module."
