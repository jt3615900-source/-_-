#!/usr/bin/env bash
set -euo pipefail
apt-get update
apt-get install -y shadowsocks-libev
cat >/etc/shadowsocks-libev/mrtom.json <<'EOF'
{
  "server":["::0","0.0.0.0"],
  "mode":"tcp_and_udp",
  "server_port":8388,
  "password":"CHANGE_ME",
  "timeout":300,
  "method":"chacha20-ietf-poly1305"
}
EOF
chmod 600 /etc/shadowsocks-libev/mrtom.json
systemctl enable --now shadowsocks-libev-server@ || true
echo "[OK] Shadowsocks installé sur 8388."
