#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
ZIV VPN : module d'intégration.
Le nom "ZIV VPN" ne désigne pas un protocole standard unique. Pour une installation réellement fonctionnelle,
il faut connaître le logiciel/serveur ZIV exact (nom du projet, lien GitHub ou paquet).

Le module ne télécharge volontairement aucun binaire inconnu.
EOF
