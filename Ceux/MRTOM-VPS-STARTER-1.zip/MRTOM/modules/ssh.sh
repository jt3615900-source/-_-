#!/usr/bin/env bash
set -euo pipefail
mkdir -p /etc/mrtom
apt-get install -y openssh-server
# SSH principal : 22. Les ports 80/443 sont réservés aux services web/multiplexés.
sed -i 's/^#\?Port .*/Port 22/' /etc/ssh/sshd_config
systemctl enable --now ssh
echo "[OK] OpenSSH : 22"
