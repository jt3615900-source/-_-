#!/usr/bin/env bash
set -euo pipefail
source /etc/mrtom/config.env
apt-get install -y nginx
cat >/etc/nginx/sites-available/mrtom <<EOF
server {
    listen 80 default_server;
    server_name ${MRTOM_DOMAIN};
    root /var/www/mrtom;
    index index.html;
}
EOF
mkdir -p /var/www/mrtom
cat >/var/www/mrtom/index.html <<EOF
<!doctype html><html><head><meta charset="utf-8"><title>MR TOM VPS</title></head>
<body style="font-family:Arial;text-align:center;padding:60px">
<h1>꧁༒•⪨𝑴𝑹 𝑻𝑶𝑴⪩•༒꧂</h1>
<h2>SERVER-VPS-VIP</h2><p>Service MRTOM opérationnel.</p>
</body></html>
EOF
ln -sf /etc/nginx/sites-available/mrtom /etc/nginx/sites-enabled/mrtom
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl enable --now nginx
echo "[OK] Nginx : 80"
