#!/usr/bin/env bash
set -euo pipefail
source /etc/mrtom/config.env

# Installation officielle via paquet .deb GitHub Releases.
XRAY_VERSION="$(curl -fsSL https://api.github.com/repos/XTLS/Xray-core/releases/latest | jq -r .tag_name)"
ARCH="$(dpkg --print-architecture)"
case "$ARCH" in
  amd64) PKG_ARCH="64" ;;
  arm64) PKG_ARCH="arm64-v8a" ;;
  *) echo "Architecture non supportée par ce module : $ARCH"; exit 1 ;;
esac

TMP="$(mktemp -d)"
curl -fsSL "https://github.com/XTLS/Xray-core/releases/download/${XRAY_VERSION}/Xray-linux-${PKG_ARCH}.zip" -o "$TMP/xray.zip"
unzip -qo "$TMP/xray.zip" -d "$TMP/xray"
install -m 0755 "$TMP/xray/xray" /usr/local/bin/xray
mkdir -p /usr/local/etc/xray

cat >/usr/local/etc/xray/config.json <<'EOF'
{
  "log": {"loglevel": "warning"},
  "inbounds": [],
  "outbounds": [{"protocol": "freedom", "tag": "direct"}]
}
EOF

cat >/etc/systemd/system/xray-mrtom.service <<'EOF'
[Unit]
Description=MRTOM Xray
After=network.target

[Service]
ExecStart=/usr/local/bin/xray run -config /usr/local/etc/xray/config.json
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now xray-mrtom
echo "[OK] Xray installé."
echo "Les inbounds VMess/VLESS/Trojan/Shadowsocks doivent être générés avec un certificat TLS et des UUID/mots de passe uniques."
