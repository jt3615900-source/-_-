#!/usr/bin/env bash
set -euo pipefail

MRTOM_ETC="/etc/mrtom"
MRTOM_STATE="$MRTOM_ETC/state.env"
MRTOM_CONFIG="$MRTOM_ETC/config.env"

require_root() {
  [[ "${EUID}" -eq 0 ]] || { echo "Exécutez ce script en root."; exit 1; }
}

detect_os() {
  [[ -f /etc/os-release ]] || { echo "OS non supporté."; exit 1; }
  . /etc/os-release
  case "${ID}" in
    ubuntu|debian) ;;
    *) echo "Ubuntu/Debian requis."; exit 1 ;;
  esac
}

collect_domain() {
  mkdir -p "$MRTOM_ETC"
  if [[ -f "$MRTOM_CONFIG" ]]; then
    # shellcheck disable=SC1090
    source "$MRTOM_CONFIG"
  fi

  MRTOM_DOMAIN="${MRTOM_DOMAIN:-}"
  MRTOM_NS1="${MRTOM_NS1:-}"
  MRTOM_NS2="${MRTOM_NS2:-}"

  [[ -n "$MRTOM_DOMAIN" ]] || read -rp "Domaine lié au VPS : " MRTOM_DOMAIN
  read -rp "NS principal (ex: ns1.exemple.com) [optionnel] : " NS_INPUT || true
  [[ -n "${NS_INPUT:-}" ]] && MRTOM_NS1="$NS_INPUT"
  read -rp "NS secondaire (optionnel) : " NS2_INPUT || true
  [[ -n "${NS2_INPUT:-}" ]] && MRTOM_NS2="$NS2_INPUT"

  cat > "$MRTOM_CONFIG" <<EOF
MRTOM_DOMAIN='$MRTOM_DOMAIN'
MRTOM_NS1='$MRTOM_NS1'
MRTOM_NS2='$MRTOM_NS2'
EOF
  chmod 600 "$MRTOM_CONFIG"
}

install_base() {
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y \
    ca-certificates curl wget git unzip jq openssl \
    socat nginx ufw fail2ban \
    openssh-server dropbear \
    openvpn easy-rsa \
    dnsutils cron
}

install_manager() {
  install -d /usr/local/bin
  install -m 0755 "$PWD/mrtom" /usr/local/bin/mrtom
}

install_banner() {
  install -d /etc/mrtom/banner
  install -m 0644 "$PWD/banner/issue.net" /etc/mrtom/banner/issue.net
  cp /etc/mrtom/banner/issue.net /etc/issue.net

  if grep -qE '^Banner ' /etc/ssh/sshd_config; then
    sed -i 's|^Banner .*|Banner /etc/mrtom/banner/issue.net|' /etc/ssh/sshd_config
  else
    echo 'Banner /etc/mrtom/banner/issue.net' >> /etc/ssh/sshd_config
  fi
  systemctl restart ssh || systemctl restart sshd || true

  # Dropbear
  if grep -q '^DROPBEAR_BANNER=' /etc/default/dropbear 2>/dev/null; then
    sed -i 's|^DROPBEAR_BANNER=.*|DROPBEAR_BANNER="/etc/mrtom/banner/issue.net"|' /etc/default/dropbear
  else
    echo 'DROPBEAR_BANNER="/etc/mrtom/banner/issue.net"' >> /etc/default/dropbear
  fi
  systemctl restart dropbear 2>/dev/null || true
}

module() {
  local name="$1"
  local path="$PWD/modules/$name.sh"
  [[ -f "$path" ]] || { echo "Module inconnu: $name"; return 1; }
  bash "$path"
}
